<template>
    <div>
        <div id="cabecalho" class="row">
            <div class="col-md">Livraria do cowboy</div>
            <div class="col-md text-right"><small>Dark Mode</small></div>
        </div>
        <div>
            <div id='voltar'>
                <a @click="$router.go(-1)"><span class="fa fa-angle-left"/>  Voltar </a>
            </div>
        </div>
        <div id="form">
            <div>
                <div>Nome:</div>
                <input class="form-control" type="text" id="name" v-model="nomeLivro"/>
            </div>
            <div>
                <div>Autor(a):</div>
                <input class="form-control" type="text" id="author" v-model="autor"/>
            </div>
            <div>
                <div>Categoria:</div>
                <input class="form-control" type="text" id="categ" v-model="categ"/>
            </div>
            <div>
                <div>Quantidade em estoque:</div>
                <input class="form-control" type="text" id="qtd" v-model="qtd"/>
            </div>
            <div>
                <div>Url da capa:</div>
                <input class="form-control" type="text" id="capa" v-model="capa"/>
            </div>
            <div>
                <div>Descrição:</div>
                <textarea class="form-control" type="text-area" id="desc" rows="5" v-model="desc"/>
            </div>
            <div class="text-right">
                <button class="btn btn-dark" v-on:click="enviar()">
                    Adicionar
                </button>
            </div>
        </div>
    </div>
</template>

<script>
    import axios from "axios/dist/axios"
    export default {
        name: 'Cadastro',
        data: function (){
            return {
                usu : 'John Doe',
                nomeLivro : "",
                autor: "",
                categ: "",
                qtd: "",
                capa: "",
                desc: "",
            }
        },
        methods: {
            msgCadastroOK(){
                this.nomeLivro = ""
                this.autor     = ""
                this.categ     = ""
                this.qtd       = ""
                this.capa      = ""
                this.desc      = ""
                window.location.href = '/listar'
            },
            enviar(){
                let livro = {
                    "name"  : this.nomeLivro,
                    "author" : this.autor,
                    "category" : this.categ,
                    "stock" :this.qtd,
                    "cover_picture" : this.capa,
                    "description" : this.desc
                }
                axios({
                    "url":"http://localhost:3000/api/livros",
                    "method":"POST",
                    data : livro
                }).then(resp => {
                    let id = resp.data.id
                    if (id) 
                        this.msgCadastroOK()
                }, (err) => {
                    console.log(err)
                    console.log('----------erro------------------------------------>')
                })
            },
        }
    }
</script>

<style scoped>
    #form{
        display: flex;
        flex-direction: column;
        margin-top: 10px;
        margin-left: 33%;
        width: 33%;
    }
    #form input, #form textarea{
        font-size: 12px;
        font-family: sans-serif;
    }
    #name,#author,#categ,#qtd,#capa{
        margin-bottom: 20px;
    }
    #desc{
        height: 120px;
        margin-bottom: 20px;
    }
    #botoes{
        display: flex;
        justify-content: space-between;
    }
    #voltar{
        text-align: left;
        margin-left: 50px;
        margin-top: 10px;
    }
</style>