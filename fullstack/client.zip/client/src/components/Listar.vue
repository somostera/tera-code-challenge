<template>
    <div>
        <div id="cabecalho" class="row">
            <div class="col-md">Livraria do cowboy</div>
            <div class="col-md text-right"><small>Dark Mode</small></div>
        </div>
        <div id='filtros'>
            <div class="input-group" >
                <input cass="form-control" type="text" v-model="nomeLivro" placeholder="Procure por um livro" @value="nomeLivro"/>
                <div class="input-group-append">
                    <button class="btn btn-info" v-on:click="buscaLivroNome(nomeLivro)"><span class="fa fa-search"/></button>
                </div>
                <div><a v-bind:href="'/cadastrar'">
                    <button class="btn btn-info"><span class="fa fa-plus"/></button>
                    </a>                
                </div>
            </div>
            <div class="btn-group">
                <div class="dropdown">
                    <button class="btn btn-light dropdown-toggle" type="button" id="dropdownMenu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Filtros
                    </button>
                </div>
                <div class="dropdown-menu" aria-labelledby="dropdownMenu2">
                    <button class="dropdown-item" type="button">Action</button>
                    <button class="dropdown-item" type="button">Another action</button>
                    <button class="dropdown-item" type="button">Something else here</button>
                </div>
            </div>
        </div>
        <div id="total">
            <p>Total: {{tot}}</p>
        </div>
        <div class="container" id="livros" >
            <div class="row">
                <div class="col-3" v-for="livro in livros" v-bind:key="livro.id">
                    
                    <div class="imgLivro">
                        <a v-bind:href="`alterar/${livro.id}`">
                        <img v-if="livro.cover_picture != ''" :src="livro.cover_picture"/>
                        <img v-else src="" alt="Sem Capa" />
                        </a>
                    </div>
                    <div id=coracao>
                        <p>
                          <strong>{{livro.name}}</strong>
                        </p>
                        <p>
                            <span v-if="livro.users_who_liked && livro.users_who_liked.indexOf(usu) >= 0" id="coracao" class="fa fa-heart" v-on:click="darLike(livro.users_who_liked)" style="color:red;"/>
                            <span v-else id="coracao" class="fa fa-heart-o" v-on:click="darLike(livro.users_who_liked, livro.id)"/>
                        </p>
                    </div>
                    <div id='autor'>
                        {{livro.author}}
                        <br/>
                        {{livro.category}}
                    </div>
                </div>
            </div>
            <div id="nav">
                <div v-on:click="prevPage(pagAtual)"><span class="fa fa-angle-left"/></div>
                <div v-bind:class="{ negrito: pagina == pagAtual + 1}"  v-on:click="vaPara(pagina - 1)" v-for="pagina in paginas" v-bind:key="pagina"> {{pagina}} </div>
                <div v-on:click="nextPage(pagAtual)"><span class="fa fa-angle-right"/></div>
            </div>
        </div>
    </div>
</template>

<script>
    import axios from "axios/dist/axios"
    export default {
        name: 'Lista',
        data: function (){
            return {
                usu : 'John Doe',
                livros : {},
                tot : 0,
                nomeLivro : "",
                pagAtual: 0,
                numPag : 0,
                paginas : [],
                limit: 8
            }
        },
        methods:{
            buscaLivroNome(nome){
                axios({
                    "url":"http://localhost:3000/api/livros?limit="+ this.limit +"&name=" + nome,
                    "method":"GET"
                }).then(resp => {
                    this.tot = resp.data.numReg
                    this.livros =resp.data.livros
                    this.nomeLivro = ""
                })
            },
            vaPara(pag){
                if (pag < 0 || pag >= this.numPag){
                    return
                }
                axios({
                    "url":"http://localhost:3000/api/livros?limit=" + this.limit + "&page="+ pag,
                    "method":"GET"
                }).then(resp => {
                    this.tot = resp.data.numReg
                    this.livros =resp.data.livros
                    this.pagAtual = parseInt(resp.data.pagAtual)
                })
            },
            darLike(likers, id){
                let posI = likers.indexOf(this.usu) 
                
                if (posI >= 0){
                    
                    let arr = likers.split(',')
                    
                    arr.filter((item) =>{
                        return item.toUpperCase() != this.usu.toUpperCase()
                    })
                    likers = arr.toString()

                } else {           
                    likers += this.usu
                }
                axios({
                    "url":"http://localhost:3000/api/livros/"+ id,
                    "method": "PUT",
                    data : {"users_who_liked" : likers + "," + this.usu}
                }).then(resp => {
                    console.log(resp)
                    let id = resp.data.id
                    if (id) 
                        this.msgCadastroOK()
                    this.vaPara(this.pagAtual)
                }, (err) => {
                    console.log(err)
                })
            },
            contem(item) {
                return item.toUpperCase() != this.usu.toUpperCase();
            },
            vaiPraLista(){
                window.location.href = '/listar'
            }
        },
        created(){
            axios({
                "url":"http://localhost:3000/api/livros?limit=" + this.limit,
                "method":"GET"
                }).then(resp => {
                this.tot = resp.data.numReg
                this.livros =resp.data.livros
                this.pagAtual = parseInt(resp.data.pagAtual)
                this.numPag = parseInt(resp.data.numPag)
                for (let i = 1; i <= this.numPag; i++){
                    this.paginas.push(i)
                }
            })
        }
}

</script>

<style scoped>
  #app{
    background-color: #edfffa;
    height:800px;
  }
  #cabecalho{
    padding-top: 15px;
    padding-right: 50px;
    padding-bottom: 15px;
    padding-left: 50px;
    background-color: #8dd1d8;
    color: #fff;
    font-size: 30px;
  }
  #filtros{
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-top: 10px;
  }

  #filtros>div>input{
    margin-left: 50px;
  }
  #dropdownMenu{
    margin-right:50px;
  }
  #total{
    margin-left: 50px;
  }
  #livro{
    border:1px solid;
    height: 200px;
    align-items: center;
  }
  #coracao{
    display: flex;
    justify-content: space-between;
    margin-right: 10px;
    margin-top: 15px;  
  }
  .imgLivro img{
    display: flex;
     justify-content: space-around;
    height:150px;
  }
  #autor{
    font-size: 10px;
    margin-top: -27px;
    margin-bottom: 35px;
  }
  #nav{
    display: flex;
    justify-content: center;
    align-items: baseline
  }
  #nav div{
    width: 20px;
  }
  .negrito{
    font-weight: bolder;
  }

</style>