<template>
    <div>
        <div id="cabecalho" class="row">
            <div class="col-md">Livraria do cowboy</div>
            <div class="col-md text-right"><small>Dark Mode</small></div>
        </div>
        <div>
            <div id='voltar'>
                <a @click="$router.go(-1)"><span class="fa fa-angle-left"/>  Voltar </a>
            </div>
        </div>
        <div id="form">
            <div>
                <div>Nome:</div>
                <input class="form-control" type="text" id="name" v-model="nomeLivro"/>
            </div>
            <div>
                <div>Autor(a):</div>
                <input class="form-control" type="text" id="author" v-model="autor"/>
            </div>
            <div>
                <div>Categoria:</div>
                <input class="form-control" type="text" id="categ" v-model="categ"/>
            </div>
            <div>
                <div>Quantidade em estoque:</div>
                <input class="form-control" type="text" id="qtd" v-model="qtd"/>
            </div>
            <div>
                <div>Url da capa:</div>
                <input class="form-control" type="text" id="capa" v-model="capa"/>
            </div>
            <div>
                <div>Descrição:</div>
                <textarea class="form-control" type="text-area" id="desc" rows="5" v-model="desc"/>
            </div>
            <div id="botoes">
                <div class="text-left">
                    <button class="btn btn-dark" v-on:click="executa('DELETE')">
                        Deletar
                    </button>
                </div>
                <div class="text-right">
                    <button class="btn btn-dark" v-on:click="executa('PUT')">
                        Atualizar
                    </button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import axios from "axios/dist/axios"
    export default {
        props: ["id"],
        name: 'Cadastro',
        data: function (){
            return {
                usu : 'John Doe',
                nomeLivro : "",
                autor: "",
                categ: "",
                qtd: "",
                capa: "",
                desc: "",
            }
        },
        methods: {
            msgCadastroOK(){

                alert('OK')
            },
            executa(metodo){
                let livro = {
                    "name"  : this.nomeLivro,
                    "author" : this.autor,
                    "category" : this.categ,
                    "stock" :this.qtd,
                    "cover_picture" : this.capa,
                    "description" : this.desc
                }
                axios({
                    "url":"http://localhost:3000/api/livros/"+ this.id,
                    "method":metodo,
                    data : livro
                }).then(resp => {
                    console.log(resp)
                    let id = resp.data.id
                    if (id) 
                        this.msgCadastroOK()
                    this.vaiPraLista()
                }, (err) => {
                    console.log(err)
                })
            },
            vaiPraLista(){
                window.location.href = '/listar'
            }
        },created(){
            axios({
                "url":"http://localhost:3000/api/livros/" + this.id,
                "method":"GET"
                }).then(resp => {
                    let dados = resp.data
                    this.nomeLivro  = dados.name
                    this.autor      = dados.author
                    this.categ      = dados.category
                    this.qtd        = dados.stock
                    this.capa       = dados.cover_picture
                    this.desc       = dados.description
            })
        }
    }
</script>

<style scoped>
    #form{
        display: flex;
        flex-direction: column;
        margin-top: 10px;
        margin-left: 33%;
        width: 33%;
    }
    #form input, #form textarea{
        font-size: 12px;
        font-family: sans-serif;
    }
    #name,#author,#categ,#qtd,#capa{
        margin-bottom: 20px;
    }
    #desc{
        height: 120px;
        margin-bottom: 20px;
    }
    #botoes{
        display: flex;
        justify-content: space-between;
    }
    #voltar{
        text-align: left;
        margin-left: 50px;
        margin-top: 10px;
    }
</style>