import Vue from 'vue'
import Router from 'vue-router'
import Listar from './components/Listar.vue'
import Cadastrar from './components/Cadastrar.vue'
import Alterar from './components/Alterar.vue'


Vue.use(Router)

export default new Router({
  mode: 'history',
  routes : [
    {
      path: '/listar',
      name: 'Listar',
      component: Listar
    },
    {
      path: '/cadastrar',
      name: 'Cadastrar',
      component: Cadastrar
    },
    {
      path: '/Alterar/:id',
      name: 'Alterar',
      component: Alterar,
      props: true
    },
    {
      path: '/',
      redirect: '/listar'
    },
  ]
})