<template>
  <div id="app">
    <div>
      <router-view></router-view>
    </div>
  </div>
</template>

<script>
  import "bootstrap/dist/css/bootstrap.css"
  import "font-awesome/css/font-awesome.css"
  export default {
    name: 'App',
    data: function (){
      return {
      }
    },
  }
</script>

<style>
  #app{
    background-color: #edfffa;
    height:800px;
  }
  #cabecalho{
    padding-top: 15px;
    padding-right: 50px;
    padding-bottom: 15px;
    padding-left: 50px;
    background-color: #8dd1d8;
    color: #fff;
    font-size: 30px;
  }
  #filtros{
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-top: 10px;
  }

  #filtros>div>input{
   /* margin-top: 10px;*/
    margin-left: 50px;
  }
  #dropdownMenu{
    margin-right:50px;
  }
  #total{
    margin-left: 50px;
  }
  #livro{
    border:1px solid;
    height: 200px;
    align-items: center;
  }
  #coracao{
    display: flex;
    justify-content: space-between;
    margin-right: 10px;
    margin-top: 15px;  
  }
  .imgLivro{
    display: flex;
     justify-content: space-around;
    height:150px;
  }
  #autor{
    font-size: 10px;
    margin-top: -27px;
    margin-bottom: 35px;
  }
  #nav{
    display: flex;
    justify-content: center;
    align-items: baseline
  }
  #nav div{
    width: 20px;
  }
  .negrito{
    font-weight: bolder;
  }

</style>
