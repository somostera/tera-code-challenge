module.exports = (sequelize, Sequelize) => {
    const Livro = sequelize.define('livro', {
        id: {
            type: Sequelize.INTEGER,
            autoIncrement: true,
            allowNull: false,
            primaryKey: true
        },
        name: {
            type: Sequelize.STRING,
            allowNull: false
        },
        author: {
            type: Sequelize.STRING,
            allowNull: false
        },
        description: {
            type: Sequelize.STRING,
            allowNull: true
        },
        cover_picture: {
            type: Sequelize.STRING,
            allowNull: true
        },
        category: {
            type: Sequelize.STRING,
            allowNull: false
        },
        liked: {
            type: Sequelize.INTEGER,
            defaultValue: '0'
        },
        stock: {
            type: Sequelize.INTEGER,
        },
        users_who_liked: {
            type: Sequelize.STRING,
            allowNull: true,
        },
    })
    return Livro
};
