module.exports = app => {
    const livros = require("../controllers/livro.js");
  
    var router = require("express").Router();
  
    router.post("/", livros.create);
    router.get("/", livros.findAll);
    router.get("/liked", livros.findAllLiked);
    router.get("/inStock", livros.findAllInStock);
    router.get("/ordered", livros.findAllOrdered);
    router.get("/:id", livros.findOne);
    router.put("/:id", livros.update);
    router.delete("/:id", livros.delete);
    app.use('/api/livros', router);
  };