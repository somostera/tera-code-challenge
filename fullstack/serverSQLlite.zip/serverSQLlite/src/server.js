const express = require("express");
const cors = require("cors");

const app = express();

app.use(express.json());

app.use(express.urlencoded({ extended: true }));

//app.options('*', cors());

app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin",'*')
  res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  app.use(cors());
  next()
})

const db = require("./config/db.config");

db.sequelize.sync()

/*
db.sequelize.sync({ force: true }).then(() => {
  console.log("Drop and re-sync db.");
});
*/


require("./routes/routes")(app);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servdor ativo na porta ${PORT}.`);
});