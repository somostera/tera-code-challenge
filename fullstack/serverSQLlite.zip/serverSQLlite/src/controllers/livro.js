const db = require("../config/db.config");
const Livro = db.livros;
const Op = db.Sequelize.Op;


exports.create = (req, res) => {
    if (!req.body.name) {
      res.status(400).send({
        message: "O nome não pode estar vazio!"
      });
      return;
    }

    const livro = {
        name: req.body.name,
        author: req.body.author,
        description: req.body.description, 
        cover_picture: req.body.cover_picture,
        category: req.body.category,
        stock: req.body.stock,
        users_who_liked: req.body.users_who_liked
    };
  
    Livro.create(livro)
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || `Não foi possível adicionar o livro ${livro.name} à nossa livraria.`
        });
      });
};

exports.findAll = (req, res) => {
  const name = req.query.name;
  let condition = name ? { name: { [Op.like]: `%${name}%` } } : null;
  let page  = parseInt(req.query.page)
  let limit = parseInt(req.query.limit)

  const offset = page ? page * limit : 0

  Livro.findAndCountAll({ where: condition, limit : limit, offset : offset})
    .then(data => {
      let numPaginas = Math.ceil(data.count/limit)
      let dados = { 
        "numReg"    : data.count,
        "numPag"    : numPaginas,
        "pagAtual"  : !page ? 0 : page ,
        "livros"    : data.rows
      }
      res.send(dados);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Houve algum erro na execução da pesquisa."
      });
    });
};

exports.findAllOrdered = (req, res) => {
  const name = req.query.name;

  Livro.findAll({ order: [["name", "ASC"]] })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Houve algum erro na execução da pesquisa."
      });
    });
};

exports.findOne = (req, res) => {
  const id = req.params.id;

  Livro.findByPk(id)
    .then(data => {
      if (data){
        res.send(data);
      }else{
        res.send({
          message: `Não foi encontrado um livro com o id: ${id}`
          })
      }
    })
    .catch(err => {
      res.status(500).send({
        message: `Erro ao recuperar o Livro ${id}` 
      });
    });
};

exports.update = (req, res) => {
  const id = req.params.id;

  Livro.update(req.body, {
    where: { id: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: `O registro do livro foi '${req.body.name}' atualizado com sucesso.`
        });
      } else {
        res.send({
          message: `Não foi possível atualizar o livro com o id=${id}.`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: `Erro ao atualizar o livro com o id ${id} `
      });
    });
};

exports.delete = (req, res) => {
  const id = req.params.id;

  Livro.destroy({
    where: { id: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "O livro foi removido com sucesso!"
        });
      } else {
        res.send({
          message: `Não foi possível remover o livro com id=${id}`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: `Houve um erro ao tentar remover o livro com id ${id}`
      });
    });
};

exports.findAllLiked = (req, res) => {
  Livro.findAll({ where: { users_who_liked: {[Op.not]: null}} })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Houve erro em localizar os livros."
      });
    });
};

exports.findAllInStock = (req, res) => {
  Livro.findAll({ where: { stock: {[Op.gt]: 0}} })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Houve erro em localizar os livros."
      });
    });
};
